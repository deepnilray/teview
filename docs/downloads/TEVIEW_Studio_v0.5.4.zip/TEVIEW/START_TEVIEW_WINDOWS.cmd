@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 start_teview.py
    goto finish
)
where python >nul 2>nul
if not errorlevel 1 (
    python start_teview.py
    goto finish
)
echo.
echo Python 3.11 or later is needed to run experiments.
echo Install it from https://www.python.org/downloads/
echo You can still double-click OPEN_DEMO.html without Python.
:finish
echo.
echo Press any key to close this window.
pause >nul

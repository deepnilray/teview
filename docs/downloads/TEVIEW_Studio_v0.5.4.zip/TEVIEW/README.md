# TEVIEW

**Define components. Compose experiments. Inspect the equations, measurements and evidence.**

TEVIEW is an open-source, Python 3.11+ command-line tool for computational experiments. It records source and declared data, runs candidate approaches, checks measurable acceptance criteria, and produces replayable evidence bundles. You can start with an existing script or define a full experimental protocol.

TEVIEW runs locally, needs no server account, and its core has no third-party runtime dependencies. It is an **alpha**: it does not establish scientific validity, automatically reproduce untracked dependencies, or safely execute untrusted code.


## Local TEVIEW Studio: experiment code and interactive visualization

The Studio combines a text editor and the real numerical viewer side by side. Change a component property or a connection, press **Run simulation**, and see the newly computed trajectories and measurements. You can open and save `.tev` source, download CSV output, scrub the timeline and select components to inspect their recorded state. All work stays on your computer.

```bash
python -m pip install .
teview --studio
```

The server binds only to `127.0.0.1`; no internet connection or account is needed. The Windows executable also offers **7. Open graphical Studio**. Studio is not a trusted multiuser server, and numerical replay does not mean physical accuracy. See [Studio manual](docs/STUDIO.md).

## Composable physical experiments (new in v0.4 alpha)

TEVIEW now includes an initial **text-first physical scene compiler**, separate from its established experiment evidence runner. It defines reusable physical components, finds supported interactions from their properties, and runs coupled mechanical / ideal DC / electrothermal models **without programming each experimental arrangement**.

```bash
tev scene-check examples/scenes/electrothermal.tev
tev scene-explain examples/scenes/ball_water_spring.tev
tev simulate examples/scenes/electrothermal.tev --out runs/lamp
tev scene-verify runs/lamp
```

Try the independent examples: `examples/scenes/electrothermal.tev` uses a reusable bulb definition, battery and switch; `examples/scenes/ball_water_spring.tev` combines a charged sphere, electric field, liquid, floor and spring. Change a component property or connection and rerun; no demo-specific handler is required. The scene language is also TOML with dimension-checked SI units.

The lamp only emits optical power if the computed electrical network dissipates power in it. A static external field alone does not drive the DC circuit. Physical predictions are limited to the implemented laws; **TEVIEW is not yet a universal physics or multiphysics simulator**. Read the precise model and limitations in [composable physical scenes](docs/composable-physics.md).

## Compose charged objects and measure emergent fields (v0.5 alpha)

Electrostatic interactions now arise from the same charged objects regardless of
what the experiment is called. A freely moving charged sphere repels or attracts
other charged spheres and independently declared fixed point-charge sources.
Field probes measure the resulting field and potential **without influencing
it**. A uniform applied field adds by superposition. The model uses a
homogeneous three-dimensional Coulomb law sampled in the two-dimensional
motion plane; `relative_permittivity` adjusts the linear dielectric assumption.

```bash
tev scene-check examples/scenes/electrostatic_field.tev
tev scene-explain examples/scenes/electrostatic_field.tev
tev simulate examples/scenes/electrostatic_field.tev --out runs/electrostatic
tev scene-verify runs/electrostatic
tev visualize runs/electrostatic --verify-evidence
# Open runs/electrostatic/viewer.html locally.
```

The viewer depicts charge sources and measured field arrows. It does **not**
solve fields in the browser, and its arrows indicate direction rather than
calibrated magnitude. A saved CSV provides numeric field components and
potential. The model excludes magnetic effects, induction, conduction through
materials, shielding, full 3D geometry, and interior charge distributions.

## Start with code you already have

From a clone of this repository:

```bash
python -m pip install -e .
tev capture --root examples/command --out runs/integration-v1 \
  --code integrate.py --data measurements.csv \
  -- python integrate.py
tev verify runs/integration-v1
```

The example integrates a sampled function and writes `metrics.json`. `capture` executes `python integrate.py` in a separate temporary directory containing only the explicitly declared files, saves numerical measurements and source snapshots, and produces a report. `verify` re-executes the saved command and checks that measurements and declared artifact hashes match. The command runs **with your user permissions**, not inside a security sandbox.

To capture your own existing program:

```bash
tev capture --root my-project --out runs/baseline \
  --code analyze.py --data observations.csv \
  --metrics metrics.json -- python analyze.py
```

Your script needs to write a JSON object containing finite numeric values, such as `{"error": 0.012, "runtime_ms": 43.2}`. Declare **all** source code and data files required for replay with repeated `--code` and `--data` options; undeclared imports, packages, OS dependencies, API responses and external services are **not** captured automatically. You can track output files using `--artifact results.csv`. See [capture specification](docs/capture.md).

## Decide whether a change is acceptable

Create a second run after changing the implementation (without changing the experiment or dataset):

```bash
tev capture --root examples/command --out runs/integration-v2 \
  --code integrate.py --data measurements.csv \
  -- python integrate.py
tev gate runs/integration-v1 runs/integration-v2 \
  --policy examples/command/gate.toml --verify-evidence
```

The gate compares candidate metrics to a baseline and applies explicit regression budgets. The provided example policy requires numerical error not to regress by more than 0.0001 and the sample count not to decrease. A rejected candidate returns exit code **2**, so it can fail CI; invalid evidence or a command failure returns **1**. Both runs must have the same command specification, datasets, design and measurement units unless explicitly overridden for a reviewed change. The gate measures a **defined policy**, not statistical significance.

You can inspect the machine-readable verdict or write it to a file:

```bash
tev gate runs/integration-v1 runs/integration-v2 \
  --policy examples/command/gate.toml --json-out gate-result.json
```

Without `--verify-evidence`, the gate reads the reports but does not re-execute them. For high-trust decisions, use `--verify-evidence` with reviewed code. Captured commands and Python plugins are not sandboxed.

## Design experiments with structured protocols

If you want multiple experimental arms, seeded replications, step dependencies, declared datasets and exploratory hypotheses, use a `.tev` protocol (TOML). You don't need to learn a proprietary language.

```bash
tev init my-study
tev validate my-study/experiment.tev
tev run my-study/experiment.tev --out runs/study --allow-python
tev verify runs/study --allow-python
```

`init` generates an editable sample project, including the protocol, Python function, and regression policy. Replace the sample computation with your actual research code. Use `--allow-python` **only for trusted scripts**.

A non-Python synthetic A/B experiment runs without executing extension code:

```bash
tev plan examples/ab_test/experiment.tev
tev run examples/ab_test/experiment.tev --out runs/ab
tev verify runs/ab
```

The tool currently has built-in operators `bernoulli`, `ratio`, `mean`, `linear`, and `csv_column`. For your own logic, specify `python:relative_file.py:function` and opt into Python execution. Full syntax: [protocol specification](docs/protocol.md).

## What a TEVIEW run contains

- `report.json` and `REPORT.md`: measurements and accurately limited claim/guard assessments
- Snapshots of explicitly declared source and data under `source/`
- Captured commands: `capture.json`, `metrics.json`, `stdout.txt`, `stderr.txt`
- Structured protocols: `protocol.json`, `measurements.csv`, `lineage.json`

A passing `tev verify` means declared computations replayed in the **current environment**. It does not prove the model is correct, that all dependencies were captured, that the reported effect is causal, or that a different machine will reproduce it.

## Where TEVIEW fits

Experiment platforms such as MLflow and DVC already offer sophisticated metrics, pipelines and experiment tracking; ReproZip offers more extensive dependency capture. TEVIEW is smaller. Its focus is a text-first **measurable acceptance gate backed by replayable evidence**, usable with ordinary local command-line programs and without mandatory infrastructure. It is not a replacement for those mature systems or for specialized physics, statistics, hardware, or workflow engines.


## Visual playback (v0.4.1 alpha)

Physics scenes can now be viewed in a browser without creating a new
visual simulation or installing a JavaScript package:

```bash
python tev.py simulate examples/scenes/combined_lab.tev --out runs/lab
python tev.py visualize runs/lab
# Open runs/lab/viewer.html in your browser.
```

The standalone HTML player embeds the compiled model and numeric samples. It
draws the actual sphere trajectories, springs, water levels, electric-field
direction, floor, lamps and circuit summary, with play/pause, speed, timeline
scrubbing and recorded measurement charts. The viewer is independent of the
physics solver: changing a diagram cannot change numerical evidence.

**Limitations:** 2D depiction of the simplified components only. The player
interpolates saved timesteps, so collisions can visually smooth between frames.
Light glow and field glyphs are explanatory graphics, not computed ray-tracing
or field intensity maps. Runs are not scientifically validated by rendering.

## Numerical reliability: time-step refinement

Use `scene-converge` before trusting a simulated trajectory. It reruns the same scene
at `dt`, `dt/2` and `dt/4`, compares dynamically computed final-state observables,
and returns exit code **2** if the two finest resolutions differ beyond tolerance:

```bash
tev scene-converge examples/scenes/ball_water_spring.tev --rtol 1e-3 --atol 1e-6 \
  --json-out convergence.json
```

The output reports each observable's value, measured difference, tolerance and
status. Relative tolerances scale with the observable's change from its initial
value (rather than absolute coordinates or Kelvin offset). The absolute tolerance
is interpreted in the corresponding SI unit; select appropriate values for your
observable. **Refinement stability is not scientific validation**, especially
across discrete collisions and discontinuous changes. Details and adoption
criteria: [engineering strategy](docs/engineering-strategy.md).

## Development

```bash
python -m unittest discover -s tests -v
```

CI exercises Windows, macOS and Linux with Python 3.11 and 3.13, including command capture, replay and the gate. See [architecture](docs/architecture.md), [security policy](SECURITY.md) and [contributing](CONTRIBUTING.md). Licensed under MIT.

**Status: v0.5.3 alpha.** Backward compatibility is not yet guaranteed. External user adoption and independent scientific validation have not been established.

## 0.5.1a0 (engineering reliability, unreleased)

- New `tev scene-converge` CLI command runs `dt`, `dt/2` and `dt/4` to check final-state numerical sensitivity, with explicit SI-aware tolerance reporting and exit codes.
- Added six independent diagnostic tests for analytically stable trajectories, under-resolved oscillators, invalid tolerances and resource limits.
- Added `docs/engineering-strategy.md` documenting architecture, priorities, risk register and release gates.
- Physics kernels are unchanged; no unsupported claims of solver accuracy or new domains.

## 0.5.0a0 — Electrostatic composition and measured fields

- Added freely moving charge–charge Coulomb interactions and stationary point-charge field sources.
- Added noninvasive probes with time-series electric field components and potential.
- Added a uniform relative-permittivity parameter and inverse-square, superposition, momentum and energy regression tests.
- Extended offline playback to draw charge sources and recorded vector-field probes.
- Added opt-in replay verification before generating a viewer and computational work budget.
- Retained the previous experiment runner, evidence capture, gates, and visual player.
- Limitation: this is a bounded planar mechanics / idealized Coulomb model, not Maxwell or multiphysics PDE solving.

## v0.4.1 alpha

- Add offline visual playback for saved physics scenes (`tev visualize`).
- Render component geometry, recorded trajectories and numerical plots from the saved simulation, with time scrubbing and playback.
- Keep scientific model and evidence independent of visualization.

# Changelog

## 0.5.3-alpha — 2026-10-19

Added loopback-only TEVIEW Studio: real edit-and-rerun flow for trusted declarative physics scenes, bundled examples, scientific viewer with replay status, `.tev` import/export, CSV output, session-token and origin checks, interactive workload limits, and cross-browser-size regression tests. The Studio runs the existing solver; it does not add unvalidated physical effects or internet execution.


## v0.4.0a0 — Composable physical-scene kernel

- Implemented reusable typed components, physically grounded interaction discovery and dimensional checks.
- Added the first 2D mechanical, fluid buoyancy, compliant rope/spring, ideal DC circuit, and electrothermal lamp models.
- Added `scene-check`, `scene-explain`, `simulate`, and `scene-verify` commands.
- Added two composed scene examples, analytical law tests, negative/failure tests and replay validation.
- Preserved the v0.3 computational experiment, capture and regression-gate interfaces.
- Documented unsupported physics and solver limitations; intentionally do not claim universal simulation.

# Changelog

## 0.5.3-alpha — 2026-10-19

Added loopback-only TEVIEW Studio: real edit-and-rerun flow for trusted declarative physics scenes, bundled examples, scientific viewer with replay status, `.tev` import/export, CSV output, session-token and origin checks, interactive workload limits, and cross-browser-size regression tests. The Studio runs the existing solver; it does not add unvalidated physical effects or internet execution.


## 0.3.0-alpha — Adoption workflow

- Capture existing command-line computations with declared files, numeric metrics and artifact hashes.
- Replay captured commands from source snapshots and reject modified inputs or metrics.
- Bootstrap an editable experiment with `tev init`.
- Compare baseline and candidate with policy-controlled `tev gate` (CI exit status 2 on regression).
- Optional evidence replay before gating; unit-consistency enforcement for structured protocols.
- Add capture contract, examples and end-to-end tests across CI environments.

# Changelog

## 0.5.3-alpha — 2026-10-19

Added loopback-only TEVIEW Studio: real edit-and-rerun flow for trusted declarative physics scenes, bundled examples, scientific viewer with replay status, `.tev` import/export, CSV output, session-token and origin checks, interactive workload limits, and cross-browser-size regression tests. The Studio runs the existing solver; it does not add unvalidated physical effects or internet execution.


## 0.2.0-alpha — 2026-10-17

Initial public alpha of the code-first experiment runner. Supports TOML experiment definitions, built-in and trusted Python stages, typed output contracts, declared datasets, constraints, observations, basic experimental comparisons, replay and provenance records. Includes four examples and an automated test suite.

This release is experimental and is not a production scientific validation platform.

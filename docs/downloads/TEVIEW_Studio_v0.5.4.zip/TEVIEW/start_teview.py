#!/usr/bin/env python3
"""Dependency-free TEVIEW first-run launcher. Never downloads or executes third-party code."""
from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import uuid
import webbrowser

ROOT = Path(__file__).resolve().parent
SCENES = {
    "lamp": ("Battery, switch and lamp", ROOT / "examples/scenes/electrothermal.tev"),
    "ball": ("Ball, water and spring", ROOT / "examples/scenes/ball_water_spring.tev"),
    "charges": ("Electrostatic interaction and probes", ROOT / "examples/scenes/electrostatic_field.tev"),
    "combined": ("Coupled mechanical and thermal experiment", ROOT / "examples/scenes/combined_lab.tev"),
}
CUSTOM = ROOT / "my_experiment.tev"


def execute(*args: str) -> None:
    command = [sys.executable, str(ROOT / "tev.py"), *map(str, args)]
    print("\n$", " ".join(command[1:]), flush=True)
    p = subprocess.run(command, cwd=ROOT, check=False)
    if p.returncode:
        raise RuntimeError(f"TEVIEW returned exit status {p.returncode}: {args[0]}")


def check_system() -> None:
    if sys.version_info < (3, 11):
        raise RuntimeError(f"Python 3.11 or later is required; found {sys.version.split()[0]}. Visit https://www.python.org/downloads/")
    if not (ROOT / "tev.py").exists():
        raise RuntimeError("Missing tev.py. Extract the *entire* release ZIP before running the launcher.")


def run_scene(name: str, open_browser: bool = True, convergence: bool = False) -> Path:
    scene = CUSTOM if name == "custom" else SCENES[name][1]
    if not scene.is_file():
        raise RuntimeError(f"Missing experiment: {scene}. Choose option 5 to create one.")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    out = ROOT / "runs" / f"{name}-{stamp}"
    execute("scene-check", str(scene))
    execute("scene-explain", str(scene))
    execute("simulate", str(scene), "--out", str(out))
    execute("scene-verify", str(out))
    if convergence:
        execute("scene-converge", str(scene), "--rtol", "0.001", "--atol", "0.000001")
    execute("visualize", str(out))
    viewer = out / "viewer.html"
    if not viewer.is_file():
        raise RuntimeError("Simulation finished but viewer.html was not generated")
    print("\nVIEWER:", viewer)
    print("RESULTS:", out / "measurements.csv")
    print("MODEL:", out / "model.json")
    print("This is a model prediction, not a validated real-world measurement.")
    if open_browser:
        opened = webbrowser.open(viewer.as_uri(), new=2)
        if not opened:
            print("Open viewer.html manually using its path above.")
    return out


def copy_experiment() -> None:
    if CUSTOM.exists():
        print("Your experiment already exists:", CUSTOM)
        return
    shutil.copyfile(SCENES["ball"][1], CUSTOM)
    print("Created", CUSTOM)
    print("Edit in any text editor, change mass, charge, spring or water values, then choose option 6.")


def smoke_test() -> None:
    with tempfile.TemporaryDirectory(prefix="teview-first-run-") as temporary:
        scene = SCENES["lamp"][1]
        out = Path(temporary) / "lamp"
        execute("scene-check", str(scene))
        execute("simulate", str(scene), "--out", str(out))
        execute("scene-verify", str(out))
        execute("visualize", str(out))
        assert (out / "viewer.html").is_file()
        assert (out / "measurements.csv").is_file()
        print("FIRST-RUN SMOKE TEST PASSED")


def menu() -> None:
    while True:
        print("\nTEVIEW - SCIENTIFIC EXPERIMENTS (ALPHA)")
        for i, (key, value) in enumerate(SCENES.items(), 1):
            print(f" {i}. {value[0]}")
        print(" 5. Create editable personal experiment")
        print(" 6. Run personal experiment")
        print(" 7. Run installation self-check")
        print(" 0. Exit")
        choice = input("Choose 0-7: ").strip()
        try:
            if choice == "0":
                return
            if choice in ("1", "2", "3", "4"):
                run_scene(list(SCENES)[int(choice)-1])
            elif choice == "5":
                copy_experiment()
            elif choice == "6":
                run_scene("custom")
            elif choice == "7":
                smoke_test()
            else:
                print("Enter a number from 0 to 7.")
        except (RuntimeError, OSError) as exc:
            print("ERROR:", exc, file=sys.stderr)
            print("See START_HERE.md for troubleshooting.")


def main() -> int:
    parser = argparse.ArgumentParser(description="Start TEVIEW without package installation")
    parser.add_argument("--smoke-test", action="store_true", help="verify first-run dependencies and viewer generation")
    parser.add_argument("--run", choices=[*SCENES, "custom"], help="run named experiment noninteractively")
    parser.add_argument("--no-browser", action="store_true", help="do not automatically open generated viewer")
    parser.add_argument("--converge", action="store_true", help="also run time-step sensitivity check")
    args = parser.parse_args()
    try:
        check_system()
        if args.smoke_test:
            smoke_test()
        elif args.run:
            run_scene(args.run, not args.no_browser, args.converge)
        else:
            menu()
        return 0
    except (RuntimeError, OSError, AssertionError) as exc:
        print(f"TEVIEW SETUP ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

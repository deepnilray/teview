# Composable physical scenes: supported model and boundaries

**Status: v0.4.0 alpha.** This is a proof of a component-first compiler/kernel, not a general multiphysics solver. The existing `.tev` computational experiment format remains available. A scene `.tev` uses `[[components]]` and a `[world]` table; select it using `tev simulate` rather than `tev run`.

## Model compilation

1. The scene compiler resolves built-in component traits and reusable `[[definitions]]` into typed instances. It rejects unknown properties and dimensions.
2. A law-discovery pass inspects component types, geometry and references, constructing an interaction list independently of component names. For example, each sphere obtains gravity; each sphere/fluid pair obtains buoyancy; each spring gets Hooke's law; each lamp obtains electrical and electrothermal properties.
3. An RK4 kernel integrates 2D translational motion, with discrete frictionless contact impulses for spheres and horizontal floors. Springs have axial force and damping. Ropes are **compliant, tension-only springs**, not exact inextensible constraints.
4. Ideal DC electrical circuits use modified nodal analysis. Wires and closed switches are equipotential links; batteries are ideal voltage sources; resistors and lamps are constant-resistance loads.
5. Each lamp converts its computed DC electrical power into heat and a prescribed `light_fraction` optical output. Temperature follows a lumped heat-capacity/cooling ordinary differential equation solved exactly for a constant power over a step. Light emission is a reported power value, **not an optical field or an image**. Powered lamps can radiatively heat spheres with defined absorptivity and heat capacity using an unshadowed isotropic inverse-square approximation.
6. Results are saved as `model.json`, `report.json`, `measurements.csv` and `scene.tev`. Replaying with `tev scene-verify` checks the source snapshot and recomputed artifact bytes under the local numerical environment.

There are no experiment-specific if-statements for an Atwood machine, a floating buoy, or a powered bulb. The same compiled relationships work under new component identifiers and in different valid combinations.

## Scene syntax

```toml
schema = 1
title = "A previously unprogrammed arrangement"

[world]
gravity = [0, "-9.81 m/s^2"]
electric_field = ["15 V/m", 0]
ambient_temperature = "293.15 K"
duration = "3 s"
dt = "0.001 s"

[[components]]
id = "particle"
kind = "sphere"
position = [0, "0.25 m"]
radius = "0.1 m"
mass = "0.4 kg"
charge = "0.01 C"

[[components]]
id = "pool"
kind = "fluid"
surface = "1 m"
bottom = "-1 m"
density = "1000 kg/m^3"
```

The `[[definitions]]` section permits named component templates with `base` and default properties; the instance uses `kind = "template_name"` and may override values. This permits arbitrary arrangements and property configurations **within supported kinds**. It does not yet let an end user introduce a genuinely new system of differential equations, constitutive laws, or port types.

Numbers without units are interpreted as SI values. Explicit unit strings are dimension-checked; supported units are in `teview_physics.UNITS`. Every material property relevant to a supported law must be defined; unsupported properties are errors. For example, a magnetic field is rejected because this kernel has not implemented induction or Lorentz magnetic forces.

## Current built-ins

| Kind | Properties or interactions |
| --- | --- |
| `sphere` | radius, mass, velocity, charge, damping, restitution; optional absorption/heat capacity and temperature |
| `anchor` | fixed mechanical endpoint |
| `spring` | Hookean axial stiffness, rest length, damping |
| `rope` | axial tension only, compliant approximation |
| `fluid` | horizontally unbounded layer; density, vertical surface/bottom, linear velocity drag |
| `floor` | horizontal collision plane, restitution |
| `battery` | ideal DC voltage source, `positive` and `negative` ports |
| `resistor` | constant Ohmic conductance, `a` and `b` ports |
| `switch` | closed/open ideal conductor, `a` and `b` ports |
| `lamp` | Ohmic current, Joule heating, lumped temperature, prescribed light-power fraction and optional spatial position |

Mechanics: uniform gravity, uniform electric force `qE`, exact spherical-cap displaced volume in infinite horizontal fluid layers, Hooke's law, linear drag, and frictionless discrete sphere/floor contact. Each model is deliberately limited: there is no CFD, current induced by an external field, electromagnetic waves, physical lamp radiation spectrum, 3D rotation, deformation, friction, thermal conduction between arbitrary objects, or automatic selection of arbitrary scientific equations.

**Important:** A stationary bulb in a uniform electric field does *not* automatically glow. To dissipate steady electrical power it needs a valid electrical driving mechanism. The simulator derives this from circuit connections and DC circuit laws, not from the presence of a field label.

## Sample commands

```bash
tev scene-check examples/scenes/electrothermal.tev
tev scene-check examples/scenes/electrostatic_field.tev
tev scene-explain examples/scenes/ball_water_spring.tev
tev simulate examples/scenes/electrothermal.tev --out results/bulb
tev scene-verify results/bulb
```

## Verification and limitations

Tests include free fall against its analytical solution, mass independence, neutral buoyancy, partial immersion volume, Hooke-law oscillation period, charged-particle acceleration, momentum conservation in binary collisions, lamp current/power and thermal asymptotes, open circuits, series lamps, invalid units, inconsistent ideal voltage sources, input tampering, and old-format backward compatibility.

These demonstrate selected laws, not general scientific validation. Contacts are discrete and can tunnel at large time steps; the RK4 solver is not stable for arbitrarily stiff springs; fluid layers are horizontally infinite and cannot overlap; an electric field only affects charged mechanical spheres in this version. Results use `simulated_not_validated` until a problem has independent benchmark evidence.

## Extension direction

The architectural route to broader physics is a typed port-and-equation intermediate representation, an interaction registry with constitutive equations and conservation laws, nonlinear differential-algebraic equation solving, and verified adapters to established solvers. Extending only the object catalogue without adding correctly coupled laws will not deliver that goal.

## Solver sensitivity gate

Use `tev scene-converge <scene.tev> --rtol 1e-3 --atol 1e-6` to rerun
three step resolutions and compare final-state dynamical observables. The command
returns 0 when the two finest runs agree and 2 when they differ beyond the
stated budgets. It reports a refinement **sensitivity check**, not the exact
numerical error or true physical validity. Discrete collisions, stiff systems
and chaotic dynamics require stronger analyses and independent reference tests.

# Scientific simulation viewer — prototype

This is a technical visualization layer for the existing TEVIEW physics kernel. It **does not** integrate the equations in JavaScript. All object state and all plotted signals come from saved `model.json`, `measurements.csv`, and `report.json` produced by `tev simulate`.

## How to use

From the TEVIEW source directory:

```sh
python tev.py simulate examples/scenes/combined_lab.tev --out runs/combined
python tev.py visualize runs/combined
```

Open `runs/combined/viewer.html` in any modern browser. The file contains its own data and requires no web server, login, or external libraries.

The shareable standalone demo `demo/TEVIEW_PROTOTYPE.html` includes three precomputed runs selected from the experiment dropdown: a coupled fluid/mechanics/lamp scene, electrostatic sources and probes, and a lamp/circuit scene.

## Display semantics and scientific limits

- **Scene coordinates are metres.** One camera scale is shared by all geometry; zoom and panning do not deform the scene. Geometric sphere radii are taken from the compiled model.
- **Fluid layers are idealized infinite horizontal slabs**, not solved fluid flow. A level surface must not be interpreted as a dynamic water surface.
- **Trails are reconstructed from numerical trajectory samples.** Between saved samples, the viewer linearly interpolates display positions; it does not rerun the integrator or claim exact intermediate states.
- **Field probe arrows show measured field directions, not proportional magnitudes.** Numeric values are given in volts per metre in the inspector.
- **Fixed-charge symbols, field probes, and lamp symbols are schematic markers.** Their marker size is not physical length. Emission markers indicate modelled optical power, not a computed optical wavefront, illumination or spectral distribution.
- **Circuits without positioned components appear as a connectivity graph.** The graph is not a physical wiring layout, and only external electrical connections are shown. The circuit solver—not the graphic—determines power and current.
- The core is a restricted 2D, nonrelativistic model. A working animation is not experimental validation. The current solver does not include general 3D electrodynamics, fluid motion, arbitrary optical ray tracing, quantum fields, or particle collisions from a full event generator.

## Viewer controls

- Experiment dropdown: choose a recorded run (in the standalone demo).
- Component tree / click on geometry: select an object and inspect recorded measurements.
- Play / pause / time slider / speed: play and scrub the existing record.
- Fit, zoom, wheel, drag: navigate the metric coordinate system.
- Trails, vectors, grid: toggle overlays without changing simulation data.
- Signal dropdown: plot a recorded numerical channel.
- Export PNG: save a still image of the current stage, not a new scientific result.

## Quality verification

- `python -m unittest discover -s tests -q` covers the TEVIEW codebase.
- The optional `qa_viewer.py` uses Playwright and system Chromium to smoke-test browser interactions on desktop and mobile widths.
- The included scenes are replayable using `python tev.py scene-verify <run-folder>` after running `simulate`.

## Known further development requirements

1. Real backend-based edits and reruns, instead of playback-only property inspection.
2. A typed scene and observables exchange format with explicit versioning.
3. Flexible viewport/camera controls for large scenes and a scalable renderer for many bodies.
4. Force and field quantities that can be derived and audited from solver output, not guessed from geometry.
5. Scientific calibration against independent reference solutions.

# TEVIEW Studio: edit, simulate, inspect

TEVIEW Studio is a **local browser user interface** for the same `.tev` physics scene compiler used by the command line. The user can change source and recompute the scene without writing Python code or connecting to any service.

## Launch

Requirements: Python 3.11 or newer. After installing the project:

```bash
python -m pip install .
teview --studio
```

Or open a source checkout and run `python -m teview_desktop --studio`. On the standalone Windows launcher select **7. Open graphical Studio**. Use `--no-browser` to print the URL without opening it automatically. Use `--workspace path/to/folder` to control where run files are saved.

By default the server listens on a random port **only on 127.0.0.1**. It does not require internet access. Press Ctrl+C in the launcher terminal to stop the server. The result directories live under the user workspace at `studio-runs/<run-id>`.

## Five-minute experiment

1. Choose **Ball · spring · water** from the examples menu; the initial run will begin automatically.
2. Change `mass = "1.2 kg"` to `mass = "2.4 kg"` in the source editor.
3. Click **Run simulation** or press Ctrl+Enter.
4. Inspect the change in motion with playback, the timeline, the metric grid, object inspector, or measurement plot.
5. Download the `.tev` source, the CSV measurements, or open the full viewer in a new browser tab.
6. Use **Open .tev** to load a scene file from your computer; edit and rerun it. The file never leaves the machine.

The viewer reflects the numerical output of the model; changing a property reruns the physics engine. It does not simply animate preset trajectories.

## Reliability and security

- The local service executes **only the declarative `.tev` physical scene compiler**. Python extension programs and shell commands are not accepted through Studio.
- POST requests require an unguessable session token; requests with foreign origins or host headers are rejected. HTTP is bound to the local loopback interface and exposes only known result files.
- Interactive limits are 64 KB source, 5,000 simulation steps, 60 components, 40 moving spheres, and a work estimate limited by bodies × steps. For research-sized workloads, use the CLI.
- Deterministic replay can be enabled (on by default), but matching replay does **not** establish model accuracy. Studio marks results `simulated_not_validated`.
- Experiments with unsupported physics cannot be assumed correct merely because existing components compile. The physical models remain deliberately idealized, with no full fluid flow, Maxwell solver, or continuous collision detection.
- Do not expose this local server to the internet or use it with untrusted extensions. This is an alpha research workbench, not a multiuser scientific computing service.

## Troubleshooting

- **Python not found:** install Python 3.11+ and restart the terminal. On Windows try `py -3 -m pip install .`.
- **Package command not found:** invoke `python -m teview_desktop --studio` from the source directory, or check the Python Scripts directory is on PATH.
- **Port in use:** omit `--port` to use a random free port.
- **Simulation rejected:** read the error above the viewer. Common causes are unsupported units, missing component fields, invalid references, and oversized simulation workloads.
- **No browser opens:** use `--no-browser` and manually open the `http://127.0.0.1:...` address printed in your terminal.
- **Slow or unstable scenes:** use `tev scene-converge file.tev` from the CLI to check sensitivity to the time step. This is not full scientific validation.

## Draft recovery and run history (0.5.4 alpha)

Studio saves edits in your browser's local storage. On returning to Studio it offers to restore the draft; this is local-browser convenience, not a substitute for saving a `.tev` file. The **Previous runs** menu shows up to 20 runs from the current browser session. Selecting one reopens the computed viewer; **Load source** restores the exact scene text associated with that run. Run artifacts remain in the Studio workspace. Reloading the page resets the browser history list; saving a `.tev` file remains the durable way to distribute experiments.

# TEVIEW — First run on a new computer

TEVIEW is experimental scientific software. Treat outputs as predictions of simplified models, **not verified real-world measurements**. No subscription, server or internet connection is required to run the bundled examples once Python is installed.

## If you just want to see it (no installation)

1. Extract the **entire ZIP** into a folder.
2. Double-click `OPEN_DEMO.html` in that folder. It contains a *recorded* simulation of a sphere in water attached to a spring. You can play, pause and inspect it without Python or internet access. Changing the physics requires running the engine below.

## To run a new experiment

1. Install Python **3.11 or newer**, if it is not installed, from https://www.python.org/downloads/ . On Windows, follow the Python installer prompts to make Python accessible from the terminal. No separate scientific packages are required.
2. Extract the complete ZIP, and leave the file/folder structure intact.
3. **Windows:** double-click `START_TEVIEW_WINDOWS.cmd`. **macOS/Linux:** open a terminal in the extracted folder and type `bash START_TEVIEW_MAC_LINUX.sh`. Or on any computer use `python start_teview.py` (often `python3` on Mac/Linux).
4. Choose an experiment from the numbered menu. TEVIEW validates the scene, lists discovered interactions, simulates the physical model, replays the result, and generates an offline `viewer.html`. Your browser should open. If it doesn't, open the file path printed in the terminal.
5. To create something yourself, choose menu option 5, edit the new `my_experiment.tev` in a text editor, then choose 6 to recompute it.

## Suggested first experiments

- **Lamp (`1`):** a 12 V battery, switch and resistor-like bulb. Change `closed = true` to `closed = false` in a *copy* of `examples/scenes/electrothermal.tev` and compare the current/light output.
- **Water and spring (`2`):** change `mass = "1.2 kg"` to `mass = "0.6 kg"` in your experiment. The computed motion changes because gravity, buoyancy and spring force are recomputed.
- **Electrostatics (`3`):** move fixed charges or change their signs to see how the measured electric field and charged-sphere trajectory change.
- **Combined lab (`4`):** examine the coupled example with mechanics, water, a static electric field and an electrically powered light source. Coupling remains simplified.

## Troubleshooting

| Symptom | What to do |
| --- | --- |
| Windows says `python` not found | Install Python 3.11+ from python.org and reopen the terminal; `py -3 --version` should report the installed version. |
| `No module named tomllib` | You're running Python older than 3.11. Update Python. |
| `tev.py` or `examples` is missing | You extracted an incomplete archive or moved the launcher away from its folder. Extract the full ZIP again. |
| Browser doesn't open | Open `runs/<latest-run>/viewer.html` manually; it is an offline page. |
| `TEVIEW ERROR` during checking | Read the reported property name and units. Fix the `.tev` source before rerunning. |
| Viewer shows no movement | You may have a static electrical scene; inspect current, power and thermal measurements instead. |
| Results differ after changing time step | Numerical convergence has not been established. Use `python tev.py scene-converge my_experiment.tev --rtol 1e-3 --atol 1e-6` and investigate warnings. |

## What the checks mean

- `scene-check`: input accepted by the implemented component model; **not** proof of physical realism.
- `simulate`: numerical result produced under its documented assumptions; **not** experimental validation.
- `scene-verify`: same declared computation could be replayed in this environment.
- `scene-converge`: selected final observables were insensitive to successive step-size refinement within specified tolerances; does not prove the equations or impact detection are correct.

## Security note

Only run `.tev` scenes or Python plugins from sources you trust. TEVIEW's extension/command execution is not securely sandboxed. The starter examples are provided as local source and use no external downloads.

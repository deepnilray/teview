@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 -m pip install --user "%~dp0wheels\teview_evidence_core-0.5.2a0-py3-none-any.whl"
  if errorlevel 1 goto :failure
  py -3 -m teview_desktop --run ball
) else (
  python -m pip install --user "%~dp0wheels\teview_evidence_core-0.5.2a0-py3-none-any.whl"
  if errorlevel 1 goto :failure
  python -m teview_desktop --run ball
)
pause
exit /b 0
:failure
echo Could not install TEVIEW. Python 3.11 or newer is required: https://python.org/downloads/
pause
exit /b 1

"""Local, text-first TEVIEW Studio. Standard library only; loopback HTTP only.

Runs strictly declarative physical scenes via the same validated TEVIEW kernel.
Does not execute extension Python, shell commands, or imported experiment scripts.
"""
from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path
from urllib.parse import urlsplit
import hashlib
import json
import secrets
import shutil
import threading
import uuid
import webbrowser

from teview_physics import PhysicsError, load_scene, simulate, verify_scene
from teview_visual import render_scene, VisualError
from teview_studio_template import STUDIO_HTML

EXAMPLES = {
    'ball': ('Ball · spring · water', 'ball_water_spring.tev'),
    'lamp': ('DC circuit · heat · light', 'electrothermal.tev'),
    'charges': ('Electrostatics · field probes', 'electrostatic_field.tev'),
    'combined': ('Coupled laboratory', 'combined_lab.tev'),
    'optics': ('Optical absorption', 'opto_thermal.tev'),
}
MAX_SOURCE_BYTES = 64 * 1024
MAX_REQUEST_BYTES = 100 * 1024
MAX_STEPS = 5000
MAX_BODIES = 40
MAX_COMPONENTS = 60
MAX_COST = 150_000


class StudioError(ValueError):
    pass


def example_text(name: str) -> str:
    if name not in EXAMPLES:
        raise StudioError(f'Unknown example: {name!r}')
    resource = resources.files('teview_examples').joinpath(EXAMPLES[name][1])
    return resource.read_text(encoding='utf-8')


def validate_source(source: str, folder: Path):
    if not isinstance(source, str) or not source.strip():
        raise StudioError('Enter a scene definition before running.')
    encoded = source.encode('utf-8')
    if len(encoded) > MAX_SOURCE_BYTES:
        raise StudioError('Scene source exceeds the 64 KB local Studio limit.')
    folder.mkdir(parents=True, exist_ok=False)
    (folder / 'scene.tev').write_bytes(encoded)
    model = load_scene(folder / 'scene.tev')
    if len(model.components) > MAX_COMPONENTS or len(model.bodies) > MAX_BODIES:
        raise StudioError('Studio supports up to 60 components and 40 moving spheres per scene.')
    if model.steps > MAX_STEPS or model.steps * max(1, len(model.bodies)**2) > MAX_COST:
        raise StudioError(f'Interactive Studio limit exceeded: {model.steps} steps / {len(model.bodies)} bodies. Increase dt, shorten duration, or use the CLI for heavier simulations.')
    return model


class StudioService:
    def __init__(self, workspace: Path):
        self.workspace = Path(workspace).expanduser().resolve()
        self.runs = self.workspace / 'studio-runs'
        self.runs.mkdir(parents=True, exist_ok=True)
        self.secret = secrets.token_urlsafe(32)
        self._lock = threading.Lock()

    def run(self, source: str, *, verify: bool = True) -> dict:
        if not isinstance(verify, bool):
            raise StudioError('verify must be true or false')
        if not self._lock.acquire(blocking=False):
            raise StudioError('Another simulation is already running; wait for it to finish.')
        rid = uuid.uuid4().hex
        folder = self.runs / rid
        try:
            model = validate_source(source, folder)
            report, _ = simulate(model, folder)
            verification = verify_scene(folder) if verify else {'status': 'not_checked'}
            result = render_scene(folder)
            return {
                'run_id': rid,
                'viewer': f'/runs/{rid}/viewer.html',
                'title': model.title,
                'components': len(model.components),
                'interactions': len(model.interactions),
                'samples': result['samples'],
                'duration_s': model.duration,
                'replay_status': verification['status'],
                'simulation_status': report['status'],
                'source_sha256': hashlib.sha256(source.encode('utf-8')).hexdigest(),
            }
        except Exception:
            if folder.exists():
                shutil.rmtree(folder, ignore_errors=True)
            raise
        finally:
            self._lock.release()


def make_handler(service: StudioService):
    class StudioHandler(BaseHTTPRequestHandler):
        server_version = 'TEVIEW-Studio/0.5.4'
        def log_message(self, fmt, *args):
            # Avoid recording complete source, tokens, and query strings.
            return

        def _check_host(self):
            expected = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
            return self.headers.get('Host', '') in expected

        def _send(self, body: bytes, code: int = 200, mime: str = 'application/json; charset=utf-8'):
            self.send_response(code)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('X-Frame-Options', 'SAMEORIGIN')
            self.send_header('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src 'self'; font-src 'self'; base-uri 'none'; form-action 'none'")
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, code=200):
            self._send(json.dumps(obj, allow_nan=False).encode('utf-8'), code)

        def do_GET(self):
            if not self._check_host():
                self._json({'error': 'Invalid Host header'}, 403)
                return
            path = urlsplit(self.path).path
            if path == '/':
                page = STUDIO_HTML.replace('__TEVIEW_STUDIO_TOKEN__', service.secret)
                self._send(page.encode('utf-8'), mime='text/html; charset=utf-8')
                return
            if path == '/api/examples':
                self._json({'examples': [{'id': k, 'label': label} for k, (label, _) in EXAMPLES.items()]})
                return
            if path.startswith('/api/examples/'):
                key = path[len('/api/examples/'):]
                try:
                    self._json({'id': key, 'source': example_text(key)})
                except StudioError as e:
                    self._json({'error': str(e)}, 404)
                return
            segments = path.strip('/').split('/')
            if len(segments) == 3 and segments[0] == 'runs' and len(segments[1]) == 32 and segments[1].isalnum() and segments[2] in ('viewer.html', 'measurements.csv', 'report.json', 'scene.tev'):
                rid, filename = segments[1], segments[2]
                file = service.runs / rid / filename
                if file.is_file() and file.resolve().is_relative_to(service.runs):
                    types = {'viewer.html':'text/html; charset=utf-8', 'measurements.csv':'text/csv; charset=utf-8', 'report.json':'application/json; charset=utf-8', 'scene.tev':'text/plain; charset=utf-8'}
                    self._send(file.read_bytes(), mime=types[filename])
                else:
                    self._json({'error':'Run file not found'},404)
                return
            self._json({'error':'Not found'},404)

        def do_POST(self):
            if not self._check_host():
                self._json({'error':'Invalid Host header'}, 403);return
            if urlsplit(self.path).path != '/api/run':
                self._json({'error':'Not found'},404);return
            expected_origin = {f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'}
            if self.headers.get('Origin') not in (None, *expected_origin) or self.headers.get('X-Teview-Token') != service.secret:
                self._json({'error':'Request authorization failed'},403);return
            try:
                length = int(self.headers.get('Content-Length', '-1'))
                if not 0 < length <= MAX_REQUEST_BYTES:
                    raise StudioError('Invalid or oversized request body')
                payload = json.loads(self.rfile.read(length).decode('utf-8'))
                if not isinstance(payload, dict) or set(payload) != {'source', 'verify'}:
                    raise StudioError('Expected source and verify fields')
                result = service.run(payload['source'], verify=payload['verify'])
                self._json(result)
            except (StudioError, PhysicsError, VisualError, ValueError, UnicodeError, json.JSONDecodeError) as e:
                self._json({'error': str(e)}, 400)
            except Exception:
                self._json({'error': 'Simulation failed unexpectedly; inspect the local terminal for details.'}, 500)
                raise
    return StudioHandler


def start_studio(workspace: Path, *, open_browser: bool = True, port: int = 0) -> str:
    """Run until KeyboardInterrupt. Only exposed to the same computer."""
    if not isinstance(port, int) or port < 0 or port > 65535:
        raise StudioError('port must be between 0 and 65535')
    service = StudioService(workspace)
    httpd = ThreadingHTTPServer(('127.0.0.1', port), make_handler(service))
    httpd.daemon_threads = True
    url = f'http://127.0.0.1:{httpd.server_port}/'
    print(f'TEVIEW Studio: {url}', flush=True)
    print('Runs remain on this computer. Ctrl+C stops the server.', flush=True)
    if open_browser:
        webbrowser.open(url, new=2)
    try:
        httpd.serve_forever(poll_interval=.1)
    except KeyboardInterrupt:
        print('\nStopping TEVIEW Studio.')
    finally:
        httpd.server_close()
    return url

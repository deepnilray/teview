@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 -m teview_desktop --studio
) else (
  python -m teview_desktop --studio
)
if errorlevel 1 (
  echo.
  echo TEVIEW Studio could not start. Install Python 3.11 or newer.
  pause
)

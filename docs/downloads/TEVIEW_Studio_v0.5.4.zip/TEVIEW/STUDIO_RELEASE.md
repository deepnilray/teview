# TEVIEW Studio 0.5.4 alpha

## Start

- **Windows:** Extract the ZIP and double-click `OPEN_STUDIO_WINDOWS.cmd` (requires Python 3.11+).
- **macOS/Linux:** Extract the ZIP, then run `sh OPEN_STUDIO_MAC_LINUX.sh`.
- **Installed CLI:** `teview --studio`.
- **Windows standalone executable:** A new executable must be built on Windows from this source; the earlier TEVIEW.exe does not contain Studio.

Select an experiment; the initial scene runs automatically. Edit the `.tev` source, click **Run simulation**, and inspect the new numerical result, graphs, and components. Use **Open .tev** and **Save .tev** to exchange source files. CSV and complete standalone viewer are available after successful runs.

Studio is local-only, contains no shell/plugin execution API, and limits workloads for responsiveness. **Results are predictions of simplified physical models, not laboratory validation.**

See `docs/STUDIO.md` for installation, security and troubleshooting.

Improvement: local draft recovery and a per-session run history with source restoration. Browser automation could not run in this environment because the Chromium test binary is not installed; Python integration tests and JavaScript syntax checks pass.

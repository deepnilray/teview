#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if command -v python3 >/dev/null 2>&1; then
    exec python3 start_teview.py
elif command -v python >/dev/null 2>&1; then
    exec python start_teview.py
else
    echo 'Python 3.11 or later is required. See https://www.python.org/downloads/' >&2
    echo 'OPEN_DEMO.html works without Python.' >&2
    exit 1
fi

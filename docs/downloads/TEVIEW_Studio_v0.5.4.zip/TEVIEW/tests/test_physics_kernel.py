"""Independent analytical and metamorphic checks for the TEVIEW scene kernel."""
import copy
import json
import math
import tempfile
import unittest
from pathlib import Path
from teview_physics import PhysicsError, compile_scene, displaced_volume, load_scene, simulate, solve_circuit


def sphere(name='orb', mass=1., x=0., y=3., radius=.1, charge=0., vx=0., vy=0.):
    return dict(id=name,kind='sphere',mass=mass, radius=radius,charge=charge,
                position=[x,y], velocity=[vx,vy])


def scene(parts, world=None, connections=None, definitions=None):
    return {'schema':1, 'title':'unknown composition', 'world':world or
            {'duration':.2,'dt':.001},'components':parts,
            'connections':connections or [],'definitions':definitions or []}


class ComponentLawTests(unittest.TestCase):
    def test_freefall_analytic_independent_name(self):
        obj=sphere(name='unfamiliar_workpiece',y=7.3)
        s=compile_scene(scene([obj], {'gravity':[0,-9.81],'duration':.7,'dt':.01}))
        r,_=simulate(s)
        self.assertAlmostEqual(r['final']['unfamiliar_workpiece.y'], 7.3-.5*9.81*.7**2, places=9)
        self.assertAlmostEqual(r['final']['unfamiliar_workpiece.vy'], -9.81*.7, places=9)
        self.assertEqual(s.interactions[0]['law'],'gravity')

    def test_mass_invariance_free_fall(self):
        r1,_=simulate(compile_scene(scene([sphere(mass=1)])))
        r2,_=simulate(compile_scene(scene([sphere(mass=500)])))
        self.assertAlmostEqual(r1['final']['orb.y'],r2['final']['orb.y'],places=10)

    def test_electric_force_only_on_charge(self):
        w={'gravity':[0,0],'electric_field':[30,0],'duration':1,'dt':.01}
        s=compile_scene(scene([sphere(name='q',charge=.4,mass=2,y=0)],w))
        r,_=simulate(s)
        self.assertAlmostEqual(r['final']['q.x'],3.,places=8)
        self.assertAlmostEqual(r['final']['q.vx'],6.,places=8)
        q=compile_scene(scene([sphere(name='q',charge=0,mass=2,y=0)],w))
        self.assertEqual(simulate(q)[0]['final']['q.x'],0)

    def test_displaced_volume_exact(self):
        r=.3
        full=4/3*math.pi*r**3
        self.assertAlmostEqual(displaced_volume(r,0,-100,100),full,places=12)
        self.assertAlmostEqual(displaced_volume(r,0,-100,0),full/2,places=12)
        self.assertAlmostEqual(displaced_volume(r,2,-1,1),0.)

    def test_neutrally_buoyant_sphere(self):
        r=.15;rho=998
        m=4/3*math.pi*r**3*rho
        f=dict(id='liquid',kind='fluid',surface=3,bottom=-3,density=rho)
        s=compile_scene(scene([sphere(y=0,mass=m,radius=r),f],
            {'duration':.75,'dt':.01}))
        rep,_=simulate(s)
        self.assertAlmostEqual(rep['final']['orb.y'],0,places=9)
        self.assertAlmostEqual(rep['final']['orb.vy'],0,places=9)

    def test_sphere_floats_up(self):
        parts=[sphere(mass=.2,y=0,radius=.1),
               dict(id='water',kind='fluid',surface=3,bottom=-3,density=1000)]
        rep,_=simulate(compile_scene(scene(parts,{'duration':.1,'dt':.002})))
        self.assertGreater(rep['final']['orb.y'],0)

    def test_link_composes_unknown_component_names(self):
        parts=[sphere(name='payload',x=1,y=0),
               dict(id='fixture',kind='anchor',position=[0,0]),
               dict(id='elastic_member',kind='spring',a='fixture',b='payload',stiffness=10,
                    rest_length=.5)]
        s=compile_scene(scene(parts,{'gravity':[0,0],'duration':.1,'dt':.001}))
        rep,_=simulate(s)
        self.assertLess(rep['final']['payload.x'],1)
        self.assertIn('hooke', [i['law'] for i in s.interactions])

    def test_spring_period_analytical(self):
        parts=[sphere(name='bob',x=1,y=0),
               dict(id='fixed',kind='anchor',position=[0,0]),
               dict(id='spring1',kind='spring',a='bob',b='fixed',rest_length=.7,stiffness=25)]
        T=2*math.pi*math.sqrt(1/25)
        rep,_=simulate(compile_scene(scene(parts,{'gravity':[0,0],'duration':T,'dt':.001})))
        self.assertAlmostEqual(rep['final']['bob.x'],1,delta=.008)

    def test_rope_no_compression(self):
        parts=[sphere(x=.4,y=0),dict(id='fixed',kind='anchor',position=[0,0]),
               dict(id='line',kind='rope',a='fixed',b='orb',length=.7,stiffness=100)]
        rep,_=simulate(compile_scene(scene(parts,{'gravity':[0,0],'duration':.1,'dt':.001})))
        self.assertEqual(rep['final']['orb.x'],.4)

    def test_rope_tension(self):
        parts=[sphere(x=1,y=0),dict(id='fixed',kind='anchor',position=[0,0]),
               dict(id='line',kind='rope',a='fixed',b='orb',length=.7,stiffness=100)]
        rep,_=simulate(compile_scene(scene(parts,{'gravity':[0,0],'duration':.1,'dt':.001})))
        self.assertLess(rep['final']['orb.x'],1.)

    def test_floor_contact(self):
        parts=[sphere(y=.2,vy=-2),dict(id='plate',kind='floor',height=0,restitution=.5)]
        rep,_=simulate(compile_scene(scene(parts,{'duration':.1,'dt':.0005})))
        self.assertGreaterEqual(rep['final']['orb.y'],.1)
        self.assertGreater(rep['final']['orb.vy'],0)

    def test_collision_preserves_momentum(self):
        parts=[sphere(name='a',x=-.25,y=0,vx=1,mass=2),
               sphere(name='b',x=.25,y=0,vx=0,mass=3)]
        rep,_=simulate(compile_scene(scene(parts,{'gravity':[0,0],'duration':.4,'dt':.001})))
        end=rep['final'];momentum=2*end['a.vx']+3*end['b.vx']
        self.assertAlmostEqual(momentum,2.,places=9)
        energy=.5*2*end['a.vx']**2+.5*3*end['b.vx']**2
        self.assertAlmostEqual(energy,1.,places=7)

    def test_collisions_from_identical_centers_rejected(self):
        parts=[sphere(name='a',y=0),sphere(name='b',y=0)]
        with self.assertRaisesRegex(PhysicsError,'centers coincide'):
            simulate(compile_scene(scene(parts)))


class CircuitsAndCoupling(unittest.TestCase):
    def circuit(self, closed=True):
        return scene([
            dict(id='source',kind='battery',voltage=12),
            dict(id='switcher',kind='switch',closed=closed),
            dict(id='lamp_x',kind='lamp',resistance=24,light_fraction=.2,heat_capacity=10,cooling=.5)],
            connections=[dict(a='source.positive',b='switcher.a'),
                         dict(a='switcher.b',b='lamp_x.a'),
                         dict(a='lamp_x.b',b='source.negative')],
            world={'duration':2,'dt':.01})

    def test_lamp_lights_without_named_experiment(self):
        rep,_=simulate(compile_scene(self.circuit()))
        x=rep['final']
        self.assertAlmostEqual(x['lamp_x.current'],.5,places=10)
        self.assertAlmostEqual(x['lamp_x.light_power'],1.2,places=10)
        self.assertGreater(x['lamp_x.temperature'],293.15)

    def test_open_switch_prevents_light(self):
        rep,_=simulate(compile_scene(self.circuit(False)))
        x=rep['final']
        self.assertEqual(x['lamp_x.power'],0)
        self.assertEqual(x['lamp_x.light_power'],0)

    def test_field_does_not_falsely_energize_lamp(self):
        raw=self.circuit(False)
        raw['world']['electric_field']=['150 V/m',0]
        rep,_=simulate(compile_scene(raw))
        self.assertEqual(rep['final']['lamp_x.light_power'],0)

    def test_unconnected_lamp_dark(self):
        raw=scene([dict(id='glow',kind='lamp',resistance=10)])
        rep,_=simulate(compile_scene(raw))
        self.assertEqual(rep['final']['glow.power'],0)

    def test_resistance_changes_power(self):
        baseline=self.circuit();modified=copy.deepcopy(baseline)
        modified['components'][-1]['resistance']=48
        before=simulate(compile_scene(baseline))[0]['final']['lamp_x.power']
        after=simulate(compile_scene(modified))[0]['final']['lamp_x.power']
        self.assertAlmostEqual(before,2*after)

    def test_multiple_lamps_share_current_in_series(self):
        raw=scene([dict(id='source',kind='battery',voltage=12),
                   dict(id='a',kind='lamp',resistance=10),
                   dict(id='b',kind='lamp',resistance=20)],
            connections=[dict(a='source.positive',b='a.a'),dict(a='a.b',b='b.a'),
                         dict(a='b.b',b='source.negative')])
        x=simulate(compile_scene(raw))[0]['final']
        self.assertAlmostEqual(abs(x['a.current']),.4)
        self.assertAlmostEqual(abs(x['b.current']),.4)
        self.assertAlmostEqual(x['a.power']+x['b.power'],4.8)

    def test_short_circuit_source_rejected(self):
        raw=scene([dict(id='source',kind='battery',voltage=12)],
                   connections=[dict(a='source.positive',b='source.negative')])
        with self.assertRaisesRegex(PhysicsError,'short-circuited'):
            simulate(compile_scene(raw))

    def test_conflicting_voltage_sources_rejected(self):
        raw=scene([dict(id='a',kind='battery',voltage=9),
                   dict(id='b',kind='battery',voltage=12)],
            connections=[dict(a='a.positive',b='b.positive'),
                         dict(a='a.negative',b='b.negative')])
        with self.assertRaisesRegex(PhysicsError,'singular'):
            simulate(compile_scene(raw))

    def test_decoupled_domains_coexist(self):
        raw=self.circuit()
        raw['components'].append(sphere(name='charged',y=0,charge=.5))
        raw['world']['gravity']=[0,0]
        raw['world']['electric_field']=[10,0]
        rep,_=simulate(compile_scene(raw))
        self.assertAlmostEqual(rep['final']['charged.x'],10,places=8)
        self.assertGreater(rep['final']['lamp_x.light_power'],0)

    def test_thermal_cooling_approaches_equilibrium(self):
        raw=self.circuit();raw['world']['duration']=100
        rep,_=simulate(compile_scene(raw))
        steady=293.15+(1-.2)*6/.5
        self.assertAlmostEqual(rep['final']['lamp_x.temperature'],steady,delta=.07)


class CompilerTests(unittest.TestCase):
    def test_reusable_component_definition(self):
        raw=scene([dict(id='light',kind='custom')],definitions=[
            dict(name='custom',base='lamp',resistance='20 ohm',light_fraction=.1)])
        self.assertEqual(compile_scene(raw).components['light']['resistance'],20)

    def test_bad_units_rejected(self):
        raw=scene([sphere()]);raw['components'][0]['mass']='5 V'
        with self.assertRaisesRegex(PhysicsError,'incompatible'):
            compile_scene(raw)

    def test_unknown_field_rejected(self):
        raw=scene([sphere()]);raw['components'][0]['magic_antigravity']=True
        with self.assertRaisesRegex(PhysicsError,'unknown properties'):
            compile_scene(raw)

    def test_unknown_kind_rejected(self):
        with self.assertRaisesRegex(PhysicsError,'unknown component kind'):
            compile_scene(scene([dict(id='a',kind='warp_drive')]))

    def test_malformed_terminals_rejected(self):
        raw=self._battery();raw['connections']=[dict(a='battery.bad',b='lamp.a')]
        with self.assertRaisesRegex(PhysicsError,'Unknown electrical terminal'):
            compile_scene(raw)

    @staticmethod
    def _battery():
        return scene([dict(id='battery',kind='battery',voltage=5),
                      dict(id='lamp',kind='lamp',resistance=10)])

    def test_spring_unknown_reference_rejected(self):
        raw=scene([sphere(),dict(id='spring',kind='spring',a='orb',b='invisible',
                               stiffness=50,rest_length=1)])
        with self.assertRaisesRegex(PhysicsError,'must reference'):
            compile_scene(raw)

    def test_spring_stiffness_numeric_stability(self):
        raw=scene([sphere(),dict(id='pin',kind='anchor',position=[0,0]),
                         dict(id='stiff',kind='spring',a='pin',b='orb',
                              stiffness=100000,rest_length=1)],
                  world={'duration':.2,'dt':.1})
        with self.assertRaisesRegex(PhysicsError,'dt too large'):
            simulate(compile_scene(raw))

    def test_negative_mass_rejected(self):
        with self.assertRaisesRegex(PhysicsError,'positive'):
            compile_scene(scene([sphere(mass=-2)]))

    def test_infinite_numbers_rejected(self):
        with self.assertRaises(PhysicsError):
            compile_scene(scene([sphere(mass=float('nan'))]))

    def test_unsupported_world_property_rejected(self):
        with self.assertRaisesRegex(PhysicsError,'unknown settings'):
            compile_scene(scene([sphere()],world={'magnetic_field':[1,0]}))

    def test_excessive_steps_rejected(self):
        with self.assertRaisesRegex(PhysicsError,'Too many'):
            compile_scene(scene([sphere()],world={'duration':10000,'dt':.0001}))

    def test_reports_reproducible_file(self):
        s=compile_scene(scene([sphere()], {'duration':.04,'dt':.01}))
        with tempfile.TemporaryDirectory() as td:
            report,rows=simulate(s,td)
            self.assertEqual(json.loads((Path(td)/'report.json').read_text())['final'],report['final'])
            self.assertEqual((Path(td)/'measurements.csv').read_text().count('\n'),len(rows)+1)

    def test_overlapping_fluid_regions_rejected(self):
        parts = [sphere(),
                 dict(id='water',kind='fluid',surface=2,bottom=0,density=1000),
                 dict(id='oil',kind='fluid',surface=3,bottom=1,density=700)]
        with self.assertRaisesRegex(PhysicsError,'overlaps'):
            compile_scene(scene(parts))

    def test_disjoint_fluids_supported(self):
        parts = [sphere(y=0),
                 dict(id='water',kind='fluid',surface=1,bottom=-1,density=1000),
                 dict(id='oil',kind='fluid',surface=2,bottom=1,density=700)]
        self.assertEqual(len([i for i in compile_scene(scene(parts)).interactions
                              if i['law']=='buoyancy_and_drag']),2)

    def test_ambient_temperature_affects_cooling(self):
        raw=scene([dict(id='bulb',kind='lamp',resistance=10, temperature=300)],
                  world={'duration':2,'dt':.01,'ambient_temperature':320})
        rep,_=simulate(compile_scene(raw))
        self.assertGreater(rep['final']['bulb.temperature'],300)

    def test_scene_verify_rejects_tampering(self):
        from teview_physics import verify_scene
        root=Path(__file__).resolve().parents[1]
        source=root/'examples'/'scenes'/'electrothermal.tev'
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)
            simulate(load_scene(source),output)
            (output/'scene.tev').write_bytes(source.read_bytes())
            self.assertEqual(verify_scene(output)['status'],'replayed')
            (output/'measurements.csv').write_text('tampered\n')
            with self.assertRaisesRegex(PhysicsError,'Replay mismatch'):
                verify_scene(output)

    def test_scene_verify_rejects_source_change(self):
        from teview_physics import verify_scene
        root=Path(__file__).resolve().parents[1]
        source=root/'examples'/'scenes'/'electrothermal.tev'
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)
            simulate(load_scene(source),output)
            (output/'scene.tev').write_bytes(source.read_bytes()+b'\n# modified')
            with self.assertRaisesRegex(PhysicsError,'hash mismatch'):
                verify_scene(output)

    def test_unknown_definition_base_rejected(self):
        raw=scene([sphere()],definitions=[dict(name='alien',base='fictional')])
        with self.assertRaisesRegex(PhysicsError,'Unknown base'):
            compile_scene(raw)

    def test_invalid_array_shape_rejected(self):
        raw=scene([sphere()]);raw['components']='orb'
        with self.assertRaisesRegex(PhysicsError,'must be arrays'):
            compile_scene(raw)

    def test_lamp_radiation_heats_unrelated_sphere(self):
        root=Path(__file__).resolve().parents[1]
        s=load_scene(root/'examples/scenes/opto_thermal.tev')
        rep,_=simulate(s)
        self.assertIn('radiative_absorption',[i['law'] for i in s.interactions])
        self.assertAlmostEqual(rep['final']['emitter.light_power'],3.)
        self.assertAlmostEqual(rep['final']['receiver.absorbed_power'],0.075)
        self.assertAlmostEqual(rep['final']['receiver.temperature']-293.15,1.5,places=6)

    def test_radiation_inverse_square_distance(self):
        from teview_physics import compile_scene
        base={'schema':1,'world':{'gravity':[0,0],'duration':.1,'dt':.01},
              'components':[dict(id='cell',kind='battery',voltage=12),
                            dict(id='beacon',kind='lamp',resistance=24,position=[0,0]),
                            dict(id='orb',kind='sphere',position=[.3,0],
                                 radius=.1,mass=1,absorptivity=.5,heat_capacity=1)],
              'connections':[dict(a='cell.positive',b='beacon.a'),
                             dict(a='cell.negative',b='beacon.b')]}
        near=simulate(compile_scene(base))[0]['final']['orb.absorbed_power']
        base['components'][2]['position']=[.6,0]
        far=simulate(compile_scene(base))[0]['final']['orb.absorbed_power']
        self.assertAlmostEqual(near,4*far,places=10)

    def test_no_optical_heating_from_open_circuit(self):
        root=Path(__file__).resolve().parents[1]
        from teview_physics import compile_scene
        import tomllib
        raw=tomllib.loads((root/'examples/scenes/opto_thermal.tev').read_text())
        raw['connections']=[]
        rep,_=simulate(compile_scene(raw))
        self.assertEqual(rep['final']['receiver.absorbed_power'],0)
        self.assertEqual(rep['final']['receiver.temperature'],293.15)

    def test_absorber_requires_heat_capacity(self):
        b=sphere(y=0);b['absorptivity']=.6
        with self.assertRaisesRegex(PhysicsError,'heat_capacity'):
            compile_scene(scene([b]))

    def test_absorption_requires_emitter_position(self):
        b=sphere(y=0);b.update(absorptivity=.6,heat_capacity=1)
        lamp=dict(id='lamp',kind='lamp',resistance=10)
        with self.assertRaisesRegex(PhysicsError,'position is needed'):
            compile_scene(scene([b,lamp]))

    def test_combined_lab_all_domains_in_one_scene(self):
        root=Path(__file__).resolve().parents[1]
        model=load_scene(root/'examples/scenes/combined_lab.tev')
        report,_=simulate(model)
        names={i['law'] for i in model.interactions}
        for law in ('gravity','electric_force','buoyancy_and_drag',
                    'hooke','ideal_dc_network','joule_heating_and_emission',
                    'radiative_absorption'):
            self.assertIn(law,names)
        self.assertGreater(report['final']['payload.temperature'],293.15)
        self.assertGreater(report['final']['payload.absorbed_power'],0)
        self.assertGreater(report['final']['payload.x'],0)

    def test_examples_e2e(self):
        root=Path(__file__).resolve().parents[1]
        for filename in ('electrothermal.tev','ball_water_spring.tev','opto_thermal.tev','combined_lab.tev'):
            with self.subTest(filename=filename):
                model=load_scene(root/'examples'/'scenes'/filename)
                report,rows=simulate(model)
                self.assertGreater(len(rows),1)
                self.assertEqual(report['status'],'simulated_not_validated')


if __name__=='__main__':
    unittest.main()

"""Security, physics-replay, packaging and HTTP integration tests for Studio."""
from __future__ import annotations
import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from http.server import ThreadingHTTPServer

from teview_studio import (
    StudioService, StudioError, example_text, make_handler, validate_source, MAX_SOURCE_BYTES,
)

class StudioTests(unittest.TestCase):
    def test_bundled_scenes(self):
        for name in ('ball', 'lamp', 'charges', 'combined', 'optics'):
            with self.subTest(name=name):
                source=example_text(name)
                self.assertIn('schema = 1', source)
                self.assertIn('[[components]]', source)

    def test_source_limits(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(StudioError):
                validate_source(' ', Path(tmp)/'a')
            with self.assertRaises(StudioError):
                validate_source('a' * (MAX_SOURCE_BYTES+1), Path(tmp)/'b')

    def test_reject_invalid_units(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=example_text('ball').replace('6 cm','6 seconds')
            with self.assertRaisesRegex(ValueError, 'unit'):
                validate_source(source, Path(tmp)/'invalid')

    def test_invalid_run_has_no_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            service=StudioService(Path(tmp))
            with self.assertRaises(ValueError):
                service.run('schema = 1\n[[components]]\nid="bad"\nkind="nonexistent"\n', verify=True)
            self.assertEqual(list(service.runs.iterdir()), [])

    def test_full_simulation_and_replay(self):
        with tempfile.TemporaryDirectory() as tmp:
            service=StudioService(Path(tmp))
            data=service.run(example_text('lamp'), verify=True)
            self.assertEqual(data['replay_status'], 'replayed')
            self.assertEqual(data['simulation_status'], 'simulated_not_validated')
            self.assertTrue(data['interactions'] > 0)
            for path in ('viewer.html','scene.tev','measurements.csv','report.json'):
                self.assertTrue((service.runs/data['run_id']/path).is_file())
            self.assertTrue(data['viewer'].startswith('/runs/'))

    def test_opt_out_replay_explicit(self):
        with tempfile.TemporaryDirectory() as tmp:
            service=StudioService(Path(tmp))
            out=service.run(example_text('lamp'), verify=False)
            self.assertEqual(out['replay_status'], 'not_checked')

    def test_timestep_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=example_text('ball').replace('0.002 s','0.0003 s')
            with self.assertRaisesRegex(StudioError, 'limit'):
                validate_source(source, Path(tmp)/'expensive')

    def test_concurrent_run_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            service=StudioService(Path(tmp))
            service._lock.acquire()
            try:
                with self.assertRaisesRegex(StudioError, 'already running'):
                    service.run(example_text('lamp'))
            finally:
                service._lock.release()

class HttpStudioTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.service=StudioService(Path(self.temp.name))
        self.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.service))
        self.thread=threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.temp.cleanup()

    def request(self, method, path, body=None, headers=None):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=15)
        c.request(method,path,body=body,headers=headers or {})
        result=c.getresponse()
        data=result.read()
        status=result.status
        content=result.getheader('Content-Type')
        c.close()
        return status,content,data

    def post(self, data, *, token=None, origin=None):
        headers={'Content-Type':'application/json','X-Teview-Token':token if token is not None else self.service.secret}
        if origin is not None:
            headers['Origin']=origin
        return self.request('POST','/api/run',json.dumps(data).encode(),headers)

    def test_studio_page_served_and_token_in_page(self):
        code,mime,page=self.request('GET','/')
        self.assertEqual(code,200)
        self.assertIn(b'Scientific experiment studio',page)
        self.assertIn(self.service.secret.encode(),page)
        self.assertIn('text/html',mime)

    def test_unauthorized_write(self):
        code,_,body=self.post({'source':example_text('ball'),'verify':True},token='bad')
        self.assertEqual(code,403)
        self.assertEqual(list(self.service.runs.iterdir()),[])

    def test_forged_origin(self):
        code,_,_=self.post({'source':example_text('ball'),'verify':False},origin='https://evil.example')
        self.assertEqual(code,403)

    def test_host_header_rejected(self):
        code,_,_=self.request('GET','/',headers={'Host':'evil.example'})
        self.assertEqual(code,403)

    def test_run_http_and_viewer(self):
        code,_,body=self.post({'source':example_text('lamp'),'verify':True})
        self.assertEqual(code,200)
        reply=json.loads(body)
        self.assertEqual(reply['replay_status'],'replayed')
        code,mime,html=self.request('GET',reply['viewer'])
        self.assertEqual(code,200)
        self.assertIn('text/html',mime)
        self.assertIn(b'<!doctype html>',html.lower())
        code,_,csv=self.request('GET','/runs/'+reply['run_id']+'/measurements.csv')
        self.assertEqual(code,200)
        self.assertIn(b'time',csv)

    def test_no_directory_traversal(self):
        code,_,_=self.request('GET','/runs/../../../etc/passwd')
        self.assertEqual(code,404)

    def test_payload_shape_rejected(self):
        code,_,_=self.post({'source':example_text('lamp'),'verify':True,'shell':'cat /etc/passwd'})
        self.assertEqual(code,400)

    def test_invalid_source_error_without_engine_traceback(self):
        code,_,body=self.post({'source':'schema=1\n[[components]]\nkind="ghost"\nid="x"','verify':True})
        self.assertEqual(code,400)
        self.assertIn(b'unknown component kind',body)
        self.assertNotIn(b'Traceback',body)

if __name__ == '__main__':
    unittest.main()

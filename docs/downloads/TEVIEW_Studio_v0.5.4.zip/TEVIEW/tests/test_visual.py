"""Visual renderer integration and malicious-content regression tests."""
import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from teview_visual import VisualError, render_scene

ROOT = Path(__file__).resolve().parents[1]


class VisualTests(unittest.TestCase):
    def prepare(self, temp):
        folder = Path(temp)
        model = {'world': {'electric_field':[0,0]}, 'components': {
            'object_1': {'id':'object_1','kind':'sphere','position':[0,0],'radius':0.2,'mass':1},
            'bath': {'id':'bath','kind':'fluid','surface':1.0,'bottom':-1.0}}}
        report = {'title':'Visual test', 'status':'simulated_not_validated'}
        (folder/'model.json').write_text(json.dumps(model))
        (folder/'report.json').write_text(json.dumps(report))
        with (folder/'measurements.csv').open('w',newline='') as f:
            w=csv.writer(f);w.writerows([['time','object_1.x','object_1.y'],[0,0,0],[1,.2,.5]])
        return folder

    def test_offline_html_embeds_data(self):
        with tempfile.TemporaryDirectory() as d:
            folder=self.prepare(d)
            result=render_scene(folder)
            page=(folder/'viewer.html').read_text()
            self.assertEqual(result['samples'],2)
            self.assertIn('object_1',page)
            self.assertIn('simulation',page.lower())
            self.assertNotIn('__TEVIEW_DATA_PLACEHOLDER__',page)
            self.assertNotIn('http://',page)
            self.assertNotIn('https://',page)
            self.assertEqual(list(folder.glob('*.csv')), [folder/'measurements.csv'])

    def test_malicious_title_escaped(self):
        with tempfile.TemporaryDirectory() as d:
            folder=self.prepare(d)
            (folder/'report.json').write_text(json.dumps({'title':'</script><script>alert(1)</script>'}))
            render_scene(folder)
            page=(folder/'viewer.html').read_text()
            self.assertNotIn('</script><script>alert(1)</script>',page)
            self.assertIn(r'\u003c/script\u003e',page)

    def test_rejects_duplicate_or_backwards_times(self):
        with tempfile.TemporaryDirectory() as d:
            folder=self.prepare(d)
            (folder/'measurements.csv').write_text('time,object_1.x\n0,0\n0,1\n')
            with self.assertRaisesRegex(VisualError,'increase strictly'):render_scene(folder)

    def test_rejects_nonnumeric_data(self):
        with tempfile.TemporaryDirectory() as d:
            folder=self.prepare(d)
            (folder/'measurements.csv').write_text('time,object_1.x\n0,NaN\n')
            with self.assertRaisesRegex(VisualError,'finite'):render_scene(folder)

    def test_draws_field_probes_and_sources(self):
        with tempfile.TemporaryDirectory() as d:
            folder=self.prepare(d)
            model=json.loads((folder/'model.json').read_text())
            model['components']['charge1']={'id':'charge1','kind':'fixed_charge','position':[1,0], 'charge':1e-8}
            model['components']['probe1']={'id':'probe1','kind':'field_probe','position':[2,0]}
            (folder/'model.json').write_text(json.dumps(model))
            with (folder/'measurements.csv').open('w',newline='') as f:
                writer=csv.writer(f)
                writer.writerows([['time','object_1.x','object_1.y','probe1.electric_field_x','probe1.electric_field_y', 'probe1.potential'],
                                  [0,0,0,89.8,0,89.8],[1,.2,.5,87.3,0,88.4]])
            render_scene(folder)
            page=(folder/'viewer.html').read_text()
            self.assertIn('fixed_charge',page)
            self.assertIn('field_probe',page)
            self.assertIn('probe1.electric_field_x',page)

    def test_cli(self):
        with tempfile.TemporaryDirectory() as d:
            folder=self.prepare(d)
            r=subprocess.run([sys.executable,str(ROOT/'tev.py'),'visualize',str(folder)],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertIn('viewer.html',r.stdout)

if __name__=='__main__':unittest.main()

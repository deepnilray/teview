"""Regression checks for Studio source-level run-history and draft-recovery UX."""
import unittest
from teview_studio_template import STUDIO_HTML

class StudioHistoryTests(unittest.TestCase):
    def test_ui_elements_and_handlers(self):
        for token in ('id="history"','id="restoreRun"','function refreshHistory()', 'function saveDraft()', 'function openHistoricalRun(', 'localStorage.setItem', 'localStorage.getItem'):
            with self.subTest(token=token):
                self.assertIn(token, STUDIO_HTML)

    def test_draft_not_overwritten_on_default_load(self):
        start = STUDIO_HTML.index('async function loadExample')
        end = STUDIO_HTML.index('function localDownload',start)
        self.assertNotIn('saveDraft()', STUDIO_HTML[start:end])

if __name__ == '__main__': unittest.main()

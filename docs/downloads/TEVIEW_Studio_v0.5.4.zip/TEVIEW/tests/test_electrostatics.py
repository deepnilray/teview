"""Independent tests for composition of charges and non-invasive electrical probes."""
import copy
import math
import unittest
from teview_physics import COULOMB, PhysicsError, compile_scene, simulate


def body(name, x, charge, mass=1, radius=.01, velocity=None):
    return {'id':name,'kind':'sphere','position':[x,0], 'velocity':velocity or [0,0],
            'radius':radius, 'mass':mass, 'charge':charge}


def source(name, x, charge):
    return {'id':name, 'kind':'fixed_charge', 'position':[x,0], 'charge':charge}


def probe(name, x):
    return {'id':name, 'kind':'field_probe','position':[x,0]}


def scene(components, **world):
    return {'schema':1,'title':'electrostatic combinatorics','world':
            {'gravity':[0,0], 'duration':.01, 'dt':.001, **world},'components':components}


class CoulombInteractionTests(unittest.TestCase):
    def test_fixed_source_inverse_square(self):
        r,_=simulate(compile_scene(scene([source('ion',0,1e-9),probe('near',1),probe('far',2)])))
        initial=r['initial']
        self.assertAlmostEqual(initial['near.electric_field_x'],COULOMB*1e-9,places=8)
        self.assertAlmostEqual(initial['near.electric_field_x']/initial['far.electric_field_x'],4,places=12)
        self.assertAlmostEqual(initial['near.potential']/initial['far.potential'],2,places=12)

    def test_sign_reverses_direction(self):
        pos=simulate(compile_scene(scene([source('a',0,1e-8), probe('sensor',1)])))[0]
        neg=simulate(compile_scene(scene([source('a',0,-1e-8), probe('sensor',1)])))[0]
        self.assertAlmostEqual(pos['initial']['sensor.electric_field_x'],-neg['initial']['sensor.electric_field_x'])

    def test_superposition_and_uniform_external_field(self):
        parts=[source('left',-1,1e-8),source('right',1,1e-8),probe('origin',0)]
        r,_=simulate(compile_scene(scene(parts,electric_field=['30 V/m',0])))
        self.assertAlmostEqual(r['initial']['origin.electric_field_x'],30,places=8)
        self.assertAlmostEqual(r['initial']['origin.electric_field_y'],0,places=8)

    def test_two_body_total_momentum_conservation(self):
        parts=[body('east',-.5,5e-7,mass=2),body('west',.5,-7e-7,mass=3)]
        r,_=simulate(compile_scene(scene(parts,duration=.3,dt=.0002)))
        end=r['final']
        px=2*end['east.vx']+3*end['west.vx']
        self.assertAlmostEqual(px,0,places=10)
        self.assertIn('coulomb_pair',[v['law'] for v in r['interactions']])

    def test_two_body_energy_conservation_without_collisions(self):
        parts=[body('a',-.5,3e-7),body('b',.5,5e-7)]
        r,_=simulate(compile_scene(scene(parts,duration=.2,dt=.001)))
        def energy(row):
            kinetic=.5*(row['a.vx']**2+row['a.vy']**2+row['b.vx']**2+row['b.vy']**2)
            distance=math.hypot(row['b.x']-row['a.x'],row['b.y']-row['a.y'])
            return kinetic + COULOMB*3e-7*5e-7/distance
        self.assertAlmostEqual(energy(r['initial']),energy(r['final']),delta=1e-10)

    def test_permittivity_changes_interaction_strength(self):
        parts=[source('ion',0,1e-9),probe('p',1)]
        a=simulate(compile_scene(scene(parts)))[0]['initial']['p.electric_field_x']
        b=simulate(compile_scene(scene(parts,relative_permittivity=5)))[0]['initial']['p.electric_field_x']
        self.assertAlmostEqual(a/b,5)

    def test_probe_sees_charged_mobile_body(self):
        r,_=simulate(compile_scene(scene([body('sphere',0,1e-9),probe('meter',1)])))
        self.assertAlmostEqual(r['initial']['meter.electric_field_x'],COULOMB*1e-9)

    def test_neutral_body_feels_no_electrostatic_force(self):
        parts=[body('neutral',1,0),source('fieldsource',0,1e-6)]
        r,_=simulate(compile_scene(scene(parts,duration=1,dt=.01)))
        self.assertEqual(r['final']['neutral.x'],1)

    def test_fixed_source_accelerates_arbitrary_named_charge(self):
        parts=[body('apparatus_bob',1,1e-6,mass=1),source('unrelated_component',0,1e-6)]
        r,_=simulate(compile_scene(scene(parts,duration=.001,dt=.00001)))
        self.assertGreater(r['final']['apparatus_bob.x'],1)
        self.assertIn('fixed_charge_field',[i['law'] for i in r['interactions']])

    def test_probe_at_source_is_rejected(self):
        with self.assertRaisesRegex(PhysicsError,'inside/on charged object'):
            simulate(compile_scene(scene([source('s',0,1e-6),probe('p',0)])))

    def test_sphere_at_source_is_rejected(self):
        with self.assertRaisesRegex(PhysicsError,'inside/on charged object'):
            simulate(compile_scene(scene([source('s',0,1e-6),body('p',0,1e-6)])))

    def test_invalid_electrostatic_properties_are_rejected(self):
        for world in ({'relative_permittivity':0},{'relative_permittivity':-1},
                      {'relative_permittivity':True},{'relative_permittivity':'garbage'}):
            with self.subTest(world=world),self.assertRaises(PhysicsError):
                compile_scene(scene([source('q',0,1)],**world))
        with self.assertRaisesRegex(PhysicsError,'incompatible with charge'):
            compile_scene(scene([{'id':'bad','kind':'fixed_charge', 'position':[0,0], 'charge':'10 kg'}]))
        with self.assertRaisesRegex(PhysicsError,'unknown properties'):
            compile_scene(scene([{'id':'bad','kind':'field_probe','position':[0,0],'wrong_field':1}]))

    def test_fixed_source_is_not_an_electrical_battery(self):
        parts=[source('statics',0,1e-6),{'id':'glow','kind':'lamp','resistance':'24 ohm'}]
        r,_=simulate(compile_scene(scene(parts)))
        self.assertEqual(r['final']['glow.power'],0)

    def test_probe_law_discovery_names_sources(self):
        model=compile_scene(scene([source('q',0,1e-8),body('orb',1,2e-8),probe('meter',2)]))
        sources=[x['objects'] for x in model.interactions if x['law']=='electric_probe']
        self.assertIn(['meter','q'],sources)
        self.assertIn(['meter','orb'],sources)

    def test_workload_guard(self):
        parts=[body('q'+str(i),i+1,1e-10) for i in range(10)]
        model=compile_scene(scene(parts,duration=100,dt=.001))
        with self.assertRaisesRegex(PhysicsError,'workload'):
            simulate(model)

    def test_same_experiment_renamed_has_same_state(self):
        a=scene([source('a',0,2e-8),body('b',1,4e-8),probe('c',2)])
        b=scene([source('strange_source',0,2e-8),body('new_thing',1,4e-8),probe('detector',2)])
        x=simulate(compile_scene(a))[0]['final'];y=simulate(compile_scene(b))[0]['final']
        self.assertAlmostEqual(x['b.x'],y['new_thing.x'])
        self.assertAlmostEqual(x['c.electric_field_x'],y['detector.electric_field_x'])


if __name__=='__main__':
    unittest.main()
